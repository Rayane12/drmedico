package com.cscodetech.pharmafast.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.cscodetech.pharmafast.R;

public class RootActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected void onStart() {
        super.onStart();


    }

}