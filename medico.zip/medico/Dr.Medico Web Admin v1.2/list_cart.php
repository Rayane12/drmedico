<?php 
require 'include/navbar.php';
require 'include/sidebar.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
        <!-- Start main left sidebar menu -->
        


        <!-- Start app main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                   <div class="col-md-9 col-lg-9 col-xs-12">
                    <h1>Cart Item List</h1>
					</div>
					<div class="col-md-3 col-lg-3 col-xs-12">
					<a href="set_cart.php" class="btn btn-primary" > Add New Cart Item </a>
					</div>
                </div>
				<div class="card">
				
                               <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped v_center" id="table-1">
                                            <thead>
                                                <tr>
                                                <th class="text-center">
                                                    #
                                                </th>
                                                <th>Order Id</th>
												<th>Product Title</th>
												<th>Product Image</th>
                                                <th>Product Type</th>
                                                <th>Product Discount</th>
												<th>Product Price</th>
                                                <th>Product Quantity</th>
                                                
												
                                                <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
											<?php 
											 $stmt = $mysqli->query("SELECT * FROM `tbl_pre_product`");
$i = 0;
while($row = $stmt->fetch_assoc())
{
	$getodata = $mysqli->query("select * from tbl_prescription where id=".$row['oid']."")->fetch_assoc();
	if($getodata['c_accept'] == 1 or $getodata['c_accept'] == 2)
	{
	}
	else 
	{
	$i = $i + 1;
											?>
                                                <tr>
                                                <td>
                                                    <?php echo $i; ?>
                                                </td>
                                                <td> <?php echo $row['oid']; ?></td>
												<td> <?php echo $row['ptitle']; ?></td>
                                                <td class="align-middle">
                                                   <img src="<?php echo $row['pimg']; ?>" width="60" height="60"/>
                                                </td>
                                                <td> <?php echo $row['ptype']; ?></td>
                                               
												<td> <?php echo $row['pdiscount']; ?></td>
												<td> <?php echo $row['pprice']; ?></td>
												<td> <?php echo $row['pquantity']; ?></td>
																								
												
                                                <td><a href="set_cart.php?id=<?php echo $row['id']; ?>" class="btn btn-info">Edit</a>
												
												
												</td>
                                                </tr>
<?php } } ?>                                           
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
            </div>
					
                
            </section>
        </div>
        
       
    </div>
</div>

<?php require 'include/footer.php';?>
</body>


</html>