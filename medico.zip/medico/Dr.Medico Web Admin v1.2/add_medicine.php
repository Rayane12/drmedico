<?php 
require 'include/navbar.php';
require 'include/sidebar.php';
?>
        <!-- Start main left sidebar menu -->
        <?php
		
		if(isset($_POST['icat']))
		{
			
			
			$mtitle = stripslashes($mysqli->real_escape_string($_POST['mtitle']));
			$mstatus = $_POST['mstatus'];
			$mcat = $_POST['mcat'];
			$mbrand = $_POST['mbrand'];
			
			
			$mdesc = $mysqli->real_escape_string($_POST['mdesc']);
			date_default_timezone_set("Asia/Kolkata"); 
			$rdate = date("Y-m-d H:i:s");
							
		
if(count($_FILES['cat_img']['name']) > 3)
		{
			$msgno = "Please Select Max 3 Images Allowed!!"; 
		}
		else 
		{
		
		$arr = array();
							foreach($_FILES['cat_img']['tmp_name'] as $key => $tmp_name ){
	$file_name = uniqid().$_FILES['cat_img']['name'][$key];
	
	$file_size =$_FILES['cat_img']['size'][$key];
	$file_tmp =$_FILES['cat_img']['tmp_name'][$key];
	
	$file_type = strtolower(pathinfo($file_name,PATHINFO_EXTENSION));
	
	
	move_uploaded_file($file_tmp,"assets/product/".$file_name);
	$arr[] = "assets/product/".$file_name;

							}
							$related = implode(',',$arr);
							
				


  $table="tbl_medicine";
  $field_values=array("m_img","mtitle","mstatus","mcat","mbrand","mdesc","rdate");
  $data_values=array("$related","$mtitle","$mstatus","$mcat","$mbrand","$mdesc","$rdate");
  
$h = new Common();
	  $check = $h->InsertData($field_values,$data_values,$table);
if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Medicine Section!!',
    message: 'Medicine Insert Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
?>
<script>
setTimeout(function(){ window.location.href="add_medicine.php";}, 3000);
</script>
<?php 
		
		
		}
		}
		?>
		
		<?php 
		if(isset($_POST['ucat']))
		{
			
			
			                $mtitle = stripslashes($mysqli->real_escape_string($_POST['mtitle']));
			$mstatus = $_POST['mstatus'];
			$mcat = $_POST['mcat'];
			$mbrand = $_POST['mbrand'];
			
			
			
			
			

			 $mdesc = $mysqli->real_escape_string($_POST['mdesc']);
			date_default_timezone_set("Asia/Kolkata"); 
			$rdate = date("Y-m-d H:i:s");
			
			
	if(empty($_FILES['cat_img']['name'][0]))
							{
								$table="tbl_medicine";
						
  $field=array('mtitle'=>$mtitle,'mstatus'=>$mstatus,'mcat'=>$mcat,'mbrand'=>$mbrand,'mdesc'=>$mdesc);
  $where = "where id=".$_GET['id']."";
$h = new Common();
	  $check = $h->UpdateData($field,$table,$where);
	  
if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Medicine Section!!',
    message: 'Medicine Update Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
?>
<script>
setTimeout(function(){ window.location.href="list_medicine.php";}, 3000);
</script>
<?php 
								
							}
							else 
							{
								if(count($_FILES['cat_img']['name']) > 3)
		{
			$msgno = "Please Select Max 3 Images Allowed!!"; 
		}
		else 
		{
							$arr = array();
							foreach($_FILES['cat_img']['tmp_name'] as $key => $tmp_name ){
	$file_name = uniqid().$_FILES['cat_img']['name'][$key];
	
	$file_size =$_FILES['cat_img']['size'][$key];
	$file_tmp =$_FILES['cat_img']['tmp_name'][$key];
	
	$file_type = strtolower(pathinfo($file_name,PATHINFO_EXTENSION));
	
	
	move_uploaded_file($file_tmp,"assets/product/".$file_name);
	$arr[] = "assets/product/".$file_name;

	
							}
							$related = implode(',',$arr);
						$table="tbl_medicine";
						
  $field=array('m_img'=>$related,'mtitle'=>$mtitle,'mstatus'=>$mstatus,'mcat'=>$mcat,'mbrand'=>$mbrand,'mdesc'=>$mdesc);
  $where = "where id=".$_GET['id']."";
$h = new Common();
	  $check = $h->UpdateData($field,$table,$where);
	  
if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Medicine Section!!',
    message: 'Medicine Update Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
?>
<script>
setTimeout(function(){ window.location.href="list_medicine.php";}, 3000);
</script>
<?php 
	
		}
		}
		}
		?>
		

        <!-- Start app main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
				<?php 
				if(isset($_GET['id']))
				{
					?>
					<h1>Edit Medicine</h1>
					<?php 
				}
				else 
				{
				?>
                    <h1>Add Medicine</h1>
				<?php } ?>
                </div>
				
				<div class="card">
				
				
				<?php 
				if(isset($_GET['id']))
				{
					$sels = $mysqli->query("select * from tbl_medicine where id=".$_GET['id']."")->fetch_assoc();
					?>
					
                                <form method="post" enctype="multipart/form-data" onsubmit="return postForm()">
                                    
                                    <div class="card-body">
                                        
                                        <div class="row">
<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">

								<div class="form-group">
									<label>Medicine Images(Max 3 Images)</label>
									<input type="file" name="cat_img[]" class="form-control-file" id="projectinput8"  multiple>
									<?php 
									$im_list = explode(',',$sels['m_img']);
									foreach($im_list as $ilist)
									{
										?>
										<img src="<?php echo $ilist;?>" width="100px" height="100px"/>
										<?php 
									}
									?>
								</div>
								</div>
								
								<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">

								<div class="form-group">
									<label>Medicine Title</label>
									<input type="text" name="mtitle" placeholder="Enter Medicine Title" value="<?php echo $sels['mtitle'];?>" class="form-control" id="projectinput8" required>
								</div>
								</div>
								
								
								
								
								
								
                             
							
							 

  	

<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">
								<div class="form-group">
									<label for="cname">Medicine Status </label>
									<select name="mstatus" class="form-control" required>
									<option value="">Select Medicine Status</option>
									<option value="1" <?php if($sels['mstatus'] == 1){echo 'selected';}?>>Publish</option>
									<option value="0" <?php if($sels['mstatus'] == 0){echo 'selected';}?>>Unpublish</option>
									
									</select>
								</div>
							</div>	
							
							<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">

								<div class="form-group">
									<label>Medicine Category</label>
									<select name="mcat" class="form-control " required>
									<option value="">Select Medicine Category</option>
									<?php 
									$web = $mysqli->query("select * from category where cat_status=1");
									while($row = $web->fetch_assoc())
									{
										?>
										<option value="<?php echo $row['id'];?>" <?php if($row['id'] == $sels['mcat']){echo 'selected';}?>><?php echo $row['cat_name'];?></option>
										<?php 
									}
									?>
									</select>
								</div>
								</div>
								
								<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">

								<div class="form-group">
									<label>Medicine Brand</label>
									<select name="mbrand" class="form-control" required>
									<option value="">Select Medicine Brand</option>
									<?php 
									$web = $mysqli->query("select * from tbl_brand where status=1");
									while($row = $web->fetch_assoc())
									{
										?>
										<option value="<?php echo $row['id'];?>" <?php if($row['id'] == $sels['mbrand']){echo 'selected';}?>><?php echo $row['bname'];?></option>
										<?php 
									}
									?>
									</select>
								</div>
								</div>
								
 
											
											
											
							
							

<div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
								<div class="form-group">
									<label for="cname">Medicine Description </label>
									<textarea class="form-control" rows="5" name="mdesc" id="mdesc" style="resize: none;"><?php echo $sels['mdesc'];?></textarea>
								</div>
							</div>							
								
							</div>
                                        
										
                                    </div>
                                    <div class="card-footer text-left">
                                        <button name="ucat" class="btn btn-primary">Update Medicine</button>
                                    </div>
                                </form>
								
					<?php 
				}
				else 
				{
					?>
					
					
			
			
			
			
	
			
			
                                <form method="post" enctype="multipart/form-data" onsubmit="return postForm()">
                                    
                                    <div class="card-body">
                                        
                                        <div class="row">
<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">

								<div class="form-group">
									<label>Medicine Images(Max 3 Images)</label>
									<input type="file" name="cat_img[]" class="form-control-file" id="projectinput8" required multiple>
								</div>
								</div>
								
								<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">

								<div class="form-group">
									<label>Medicine Title</label>
									<input type="text" name="mtitle" placeholder="Enter Medicine Title" class="form-control" id="projectinput8" required>
								</div>
								</div>
								
								
								
								
								
								
                             
							
							 

  	

<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">
								<div class="form-group">
									<label for="cname">Medicine Status </label>
									<select name="mstatus" class="form-control" required>
									<option value="">Select Medicine Status</option>
									<option value="1">Publish</option>
									<option value="0">Unpublish</option>
									
									</select>
								</div>
							</div>	
							
							<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">

								<div class="form-group">
									<label>Medicine Category</label>
									<select name="mcat" class="form-control " required>
									<option value="">Select Medicine Category</option>
									<?php 
									$web = $mysqli->query("select * from category where cat_status=1");
									while($row = $web->fetch_assoc())
									{
										?>
										<option value="<?php echo $row['id'];?>"><?php echo $row['cat_name'];?></option>
										<?php 
									}
									?>
									</select>
								</div>
								</div>
								
								<div class="col-md-4 col-lg-4 col-xs-12 col-sm-12">

								<div class="form-group">
									<label>Medicine Brand</label>
									<select name="mbrand" class="form-control" required>
									<option value="">Select Medicine Brand</option>
									<?php 
									$web = $mysqli->query("select * from tbl_brand where status=1");
									while($row = $web->fetch_assoc())
									{
										?>
										<option value="<?php echo $row['id'];?>"><?php echo $row['bname'];?></option>
										<?php 
									}
									?>
									</select>
								</div>
								</div>
								

											
							
							

<div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
								<div class="form-group">
									<label for="cname">Medicine Description </label>
									<textarea class="form-control" rows="5" id="mdesc" name="mdesc" style="resize: none;"></textarea>
								</div>
							</div>							
								
							</div>
                                        
										
                                    </div>
                                    <div class="card-footer text-left">
                                        <button name="icat" class="btn btn-primary">Add Medicine</button>
                                    </div>
                                </form>
				<?php } ?>
                            </div>
            </div>
					
                
            </section>
        </div>
        
       
    </div>
</div>

<?php require 'include/footer.php';?>

<script type="text/javascript">
$(document).ready(function() {
	$('#mdesc').summernote({
		height: "500px",
		toolbar: [
    // [groupName, [list of button]]
    ['style', ['bold', 'italic', 'underline', 'clear']],
    ['font', ['strikethrough', 'superscript', 'subscript']],
    ['fontsize', ['fontsize']],
    ['color', ['color']],
    ['para', ['ul', 'ol', 'paragraph']],
    ['height', ['height']]
  ]
	});
});
var postForm = function() {
	var content = $('textarea[name="mdesc"]').html($('#mdesc').code());
}
</script>
 <style>
 .-container {
    width: 100% !important;
}
 </style>
</body>


</html>