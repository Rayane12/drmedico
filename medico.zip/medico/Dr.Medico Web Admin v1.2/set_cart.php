<?php 
require 'include/navbar.php';
require 'include/sidebar.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
        <!-- Start main left sidebar menu -->
        <?php 
		if(isset($_POST['icat']))
		{
			$attribute_id = $_POST['medicine'];
			$adata = $mysqli->query("select * from tbl_medicine_attribute where id=".$attribute_id."")->fetch_assoc();
			$pdata = $mysqli->query("select * from tbl_medicine where id=".$adata['pid']."")->fetch_assoc();
			$oid = $_POST['oid'];
			$quantity = $_POST['quantity'];
			$ptitle = $pdata['mtitle'];
            $pdiscount = $adata['discount'];
			$array = explode(',',$pdata['m_img']);
			$pimg = $array[0];
			$pprice = $adata['price'];
			$ptype = $adata['title'];
			$getodata = $mysqli->query("select * from tbl_prescription where id=".$oid."")->fetch_assoc();
			$check_product = $mysqli->query("select * from tbl_pre_product where attribute_id=".$attribute_id."")->num_rows;
			if($check_product != 0)
			{
				?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.error({
    title: 'Set Cart Section!!',
    message: 'Product Already Added Please Check On List Cart Data!!',
    position: 'topRight'
  });
  </script>
  
<?php
			}
			else if($getodata['c_accept'] == 1 or $getodata['c_accept'] == 2)
			{
			?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.error({
    title: 'Set Cart Section!!',
    message: 'Customer Order accepted Or Rejected So Not Change!!',
    position: 'topRight'
  });
  </script>
  
<?php	
			}
			else 
			{
  $table="tbl_pre_product";
  $field_values=array("oid","attribute_id","pquantity","ptitle","pdiscount","pimg","pprice","ptype");
  $data_values=array("$oid","$attribute_id","$quantity","$ptitle","$pdiscount","$pimg","$pprice","$ptype");
  
$h = new Common();
	  $check = $h->InsertData($field_values,$data_values,$table);
	  
	  $subtotal = $mysqli->query("select sum((pprice * pquantity) - (pprice * pquantity) * pdiscount/100) as full_total from tbl_pre_product where oid=".$oid."")->fetch_assoc();
	  
	  $total = number_format((float)$subtotal['full_total'] + $getodata['d_charge'], 2, '.', '');
	  
	  $table="tbl_prescription";
  $field = array('subtotal'=>number_format((float)$subtotal['full_total'], 2, '.', ''),'o_total'=>$total);
  $where = "where id=".$oid."";
$h = new Common();
	  $checks = $h->UpdateData($field,$table,$where);
	  
	  
if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Set Cart Section!!',
    message: 'Product Insert Into Cart  Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
?>
<script>
setTimeout(function(){ window.location.href="set_cart.php";}, 3000);
</script>
<?php 
		
		
		}
		}
		?>
		
		<?php 
		if(isset($_POST['ucat']))
		{
			$attribute_id = $_POST['medicine'];
			$adata = $mysqli->query("select * from tbl_medicine_attribute where id=".$attribute_id."")->fetch_assoc();
			$pdata = $mysqli->query("select * from tbl_medicine where id=".$adata['pid']."")->fetch_assoc();
			$oid = $_POST['oid'];
			$quantity = $_POST['quantity'];
			$ptitle = $pdata['mtitle'];
            $pdiscount = $adata['discount'];
			$array = explode(',',$pdata['m_img']);
			$pimg = $array[0];
			$pprice = $adata['price'];
			$ptype = $adata['title'];
			
$getodata = $mysqli->query("select * from tbl_prescription where id=".$oid."")->fetch_assoc();
	if($getodata['c_accept'] == 1 or $getodata['c_accept'] == 2)
			{
			?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.error({
    title: 'Set Cart Section!!',
    message: 'Customer Order accepted Or Rejected So Not Change!!',
    position: 'topRight'
  });
  </script>
  
<?php	
			}
			else 
			{
		
		$table="tbl_pre_product";
  $field = array('oid'=>$oid,'attribute_id'=>$attribute_id,'pquantity'=>$quantity,'ptitle'=>$ptitle,'pdiscount'=>$pdiscount,'pimg'=>$pimg,'pprice'=>$pprice,'ptype'=>$ptype);
  $where = "where id=".$_GET['id']."";
$h = new Common();
	  $check = $h->UpdateData($field,$table,$where);
	  
	   $subtotal = $mysqli->query("select sum((pprice * pquantity) - (pprice * pquantity) * pdiscount/100) as full_total from tbl_pre_product where oid=".$oid."")->fetch_assoc();
	  
	  $total = number_format((float)$subtotal['full_total'] + $getodata['d_charge'], 2, '.', '');
	  
	  $table="tbl_prescription";
  $field = array('subtotal'=>number_format((float)$subtotal['full_total'], 2, '.', ''),'o_total'=>$total);
  $where = "where id=".$oid."";
$h = new Common();
	  $checks = $h->UpdateData($field,$table,$where);
	  
if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Set Cart Section!!',
    message: 'Product Update Into Cart Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
?>
<script>
setTimeout(function(){ window.location.href="list_cart.php";}, 3000);
</script>
<?php 
	
		}
		}
		?>
		

        <!-- Start app main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
				<?php 
				if(isset($_GET['id']))
				{
					?>
					<h1>Edit Cart</h1>
					<?php 
				}
				else 
				{
				?>
                    <div class="col-md-9 col-lg-9 col-xs-12">
                    <h1>Set Cart</h1>
					</div>
					<div class="col-md-3 col-lg-3 col-xs-12">
					<a href="list_cart.php" class="btn btn-primary" > List Cart Data</a>
					</div>
				<?php } ?>
                </div>
				
				<div class="card">
				
				
				<?php 
				if(isset($_GET['id']))
				{
					$data = $mysqli->query("select * from tbl_pre_product where id=".$_GET['id']."")->fetch_assoc();
					?>
					<form method="post" enctype="multipart/form-data">
                                    
                                   <div class="card-body">
									
									<div class="form-group">
                                            <label>Select Order Id</label>
                                           <select name="oid" class="form-control " required>
									<option value="">Select Order</option>
									<?php 
									$medicine = $mysqli->query("select * from tbl_prescription where p_status='Pending' order by id desc");
									while($rmed = $medicine->fetch_assoc())
									{
										
										
									?>
									<option value="<?php echo $rmed['id'];?>" <?php if($rmed['id'] == $data['id']){echo 'selected';}?>><?php echo "ORDER ID : ".$rmed['id'];?></option>
									<?php } ?>
									</select>
                                        </div>
										
                                        <div class="form-group">
                                            <label>Select Product Type</label>
                                           <select name="medicine" class="form-control chosen-select" required>
									<option value=""></option>
									<?php 
									$medicine = $mysqli->query("select * from tbl_medicine_attribute where ostock=0");
									while($rmed = $medicine->fetch_assoc())
									{
										
										$medicines = $mysqli->query("select * from tbl_medicine where id=".$rmed['pid']."")->fetch_assoc();
									?>
									<option value="<?php echo $rmed['id'];?>" <?php if($rmed['id'] == $data['attribute_id']){echo 'selected';}?>><?php echo $medicines['mtitle'].'-- '.$rmed['title'];?></option>
									<?php } ?>
									</select>
                                        </div>
                                       
										
										<div class="form-group">
                                            <label>Set Quantity</label>
                                           <input type="text" name="quantity" class="form-control" value="<?php echo $data['pquantity'];?>" required>
                                        </div>
										
										
                                        
										
                                    </div>
                                    <div class="card-footer text-left">
                                        <button name="ucat" class="btn btn-primary">Update Testimonial</button>
                                    </div>
                                </form>
					<?php 
				}
				else 
				{
					?>
                                <form method="post" enctype="multipart/form-data">
                                    
                                    <div class="card-body">
									
									<div class="form-group">
                                            <label>Select Order Id</label>
                                           <select name="oid" class="form-control " required>
									<option value="">Select Order</option>
									<?php 
									$medicine = $mysqli->query("select * from tbl_prescription where p_status='Pending' order by id desc");
									while($rmed = $medicine->fetch_assoc())
									{
										
										
									?>
									<option value="<?php echo $rmed['id'];?>"><?php echo "ORDER ID : ".$rmed['id'];?></option>
									<?php } ?>
									</select>
                                        </div>
										
                                        <div class="form-group">
                                            <label>Select Product Type</label>
                                           <select name="medicine" class="form-control chosen-select" required>
									<option value=""></option>
									<?php 
									$medicine = $mysqli->query("select * from tbl_medicine_attribute where ostock=0");
									while($rmed = $medicine->fetch_assoc())
									{
										
										$medicines = $mysqli->query("select * from tbl_medicine where id=".$rmed['pid']."")->fetch_assoc();
									?>
									<option value="<?php echo $rmed['id'];?>"><?php echo $medicines['mtitle'].'-- '.$rmed['title'];?></option>
									<?php } ?>
									</select>
                                        </div>
                                       
										
										<div class="form-group">
                                            <label>Set Quantity</label>
                                           <input type="text" name="quantity" class="form-control" required>
                                        </div>
										
										
                                        
										
                                    </div>
                                    <div class="card-footer text-left">
                                        <button name="icat" class="btn btn-primary">Add Product In Cart</button>
                                    </div>
                                </form>
				<?php } ?>
                            </div>
            </div>
					
                
            </section>
        </div>
        
       
    </div>
</div>

<?php require 'include/footer.php';?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css" />
    
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
	<script>
	$("select").chosen({
  allow_single_deselect: true
});
	
	</script>
 <style>

select:invalid {
  height: 0px !important;
  opacity: 0 !important;
  position: absolute !important;
  display: flex !important;
}

select:invalid[multiple] {
  margin-top: 15px !important;
}

.chosen-container-single .chosen-single
{
	    height: 40px;
    background: white;
    font-size: 14px;
    color: #000 !important;
    padding: 10px 12px;
	border: 1px solid #ced4da !important; 
}
.chosen-container-single .chosen-single div b
{
	    margin-top: 50%;
}
 .select2-container {
    width: 100% !important;
}
 </style>
</body>


</html>