<?php 

require 'include/dbconfig.php';

$pid = $_POST['pid'];
$c = $mysqli->query("select * from tbl_prescription where id=".$pid."")->fetch_assoc();
$udata = $mysqli->query("select * from tbl_user where id=".$c['uid']."")->fetch_assoc();
$pdata = $mysqli->query("select * from tbl_payment_list where id=".$c['p_method_id']."")->fetch_assoc();
?>
<div style="display: flow-root;
    margin-bottom: 10px;">
<input type='button' id='btn' class="btn btn-primary text-right" value='Print Order' onclick='printDiv();' style="float:right;">
</div>


<div id="divprint">
<div style="border: 3px solid #dee2e6;
    padding: 10px;
    box-shadow: 2px 1px 1px 0px #dee2e6;
    margin-bottom: 10px;">
<h6><b>Order Id :- <?php echo $pid;?></b></h6>
<h6><b>Customer Name :- <?php echo $udata['fname'].' '.$udata['lname'];?></b></h6>
<h6><b>Customer Mobile :- <?php echo $udata['mobile'];?></b></h6>
<h6><b><p>Address :- <span><?php echo $c['address'];?></span></p></b></h6>

<?php 
$date=date_create($c['p_date']);
$order_date =  date_format($date,"d-m-Y");
?>
<h6><b>Order Date :- <?php echo $order_date;?></b></h6>

</div>

<div>
<?php 
$imglist = explode('$;',$c['p_img']);
foreach($imglist as $vlist)
{
	?>
	<img src="<?php echo $vlist;?>" width="200px" height="200px" style="padding:20px;"/>
	<?php 
}
?>
</div>

<?php 
if($c['p_method_id'] == 2 or $c['p_method_id'] == 0)
{
}
else
{
	?>
	<h6><b>Transaction Id :- <?php echo $c['trans_id'];?></b></h6>
	<?php 
}
?>
</div>
<div class="table-responsive">
<table class="table table-striped v_center">
<tr>
<th>Sr No.</th>
<th>Prodct Name</th>
<th>Prodct Image</th>
<th>Discount</th>

<th>Prodct Price</th>
<th>Product Qty</th>
<th>Product Total</th>
</tr>
<?php 

$get_data = $mysqli->query("select * from tbl_pre_product where oid=".$pid."");
$op = 0;
while($row = $get_data->fetch_assoc())
{
	$op = $op + 1;
$discount = $row['pprice'] * $row['pdiscount']*$row['pquantity'] /100;
	?>
<tr>
<td><?php echo $op;?></td>
<td style="min-width:150px;"><?php echo $row['ptitle'].' ( '.$row['ptype'].' )';?></td>
<td><img src="<?php echo $row['pimg'];?>" width="50px"/></td>
<td><?php echo $row['pdiscount'].' %';?></td>

<td><?php echo $row['pprice'].' '.$set['currency'];?></td>
<td><?php echo $row['pquantity'];?></td>
<td><?php echo ($row['pprice'] * $row['pquantity']) - $discount.' '.$set['currency'];?></td>
</tr>
<?php       
} ?>
</table>
</div>
<br>
<ul class="list-group">
<?php 
if($pdata['title'] == '')
{
}
else 
{
	?>
  <li class="list-group-item">
    <span class="badge badge-primary float-right" ><?php echo $pdata['title'];?></span> Payment Method
  </li>
<?php } ?>
  <li class="list-group-item">
    <span class="badge badge badge-secondary float-right" ><?php echo $c['subtotal'].' '.$set['currency'];?></span> Sub Total Price
  </li>
  <?php 
  if($c['cou_amt'] != 0)
  {
  ?>
   <li class="list-group-item">
    <span class="badge badge-info float-right" ><?php echo $c['cou_amt'].' '.$set['currency'];?></span> Coupon Discount
  </li>
  <?php } ?>
  
  <li class="list-group-item">
    <span class="badge badge-danger float-right" ><?php echo $c['d_charge'].' '.$set['currency'];?></span> Delivery Charge
  </li>
  
   <li class="list-group-item">
    <span class="badge badge-dark float-right" ><?php echo $c['o_total'].' '.$set['currency'];?></span> Net Amount
  </li>
  <li class="list-group-item">
    <span class="badge badge-success float-right" ><?php echo $c['p_status'];?></span> Order Status
  </li>
 
</ul>
</div>