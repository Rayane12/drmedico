<?php 
require 'include/dbconfig.php';
require 'include/Common.php';

if(isset($_SESSION['username']))
{
	?>
	<script>
	window.location.href="dashboard.php";
	</script>
	<?php 
}
else 
{
}
?>
<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<title>Login Page - <?php echo $set['d_title'];?></title>
<link rel="shortcut icon"  href="<?php echo $set['logo'];?>">
<!-- General CSS Files -->
<link rel="stylesheet" href="assets/modules/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/modules/fontawesome/css/all.min.css">
<link rel="stylesheet" href="assets/modules/izitoast/css/iziToast.min.css">
<!-- CSS Libraries -->
<link rel="stylesheet" href="assets/modules/bootstrap-social/bootstrap-social.css">

<!-- Template CSS -->
<link rel="stylesheet" href="assets/css/style.min.css">
<link rel="stylesheet" href="assets/css/components.min.css">
<style type="text/css">
	body {
  -webkit-perspective: 800px;
          perspective: 800px;
  height: 100vh;
  margin: 0;
  overflow: hidden;
  font-family: 'Gudea', sans-serif;
  background: #EA5C54;
  /* Old browsers */
  /* FF3.6+ */
  /* Chrome,Safari4+ */
  /* Chrome10+,Safari5.1+ */
  /* Opera 11.10+ */
  /* IE10+ */
  background: linear-gradient(135deg, #EA5C54 0%, #bb6dec 100%);
  /* W3C */
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#EA5C54 ', endColorstr='#bb6dec',GradientType=1 );
  /* IE6-9 fallback on horizontal gradient */
}
body ::-webkit-input-placeholder {
  color: #4E546D;
}
body .authent {
  display: none;
  background: #35394a;
  /* Old browsers */
  /* FF3.6+ */
  /* Chrome,Safari4+ */
  /* Chrome10+,Safari5.1+ */
  /* Opera 11.10+ */
  /* IE10+ */
  background: linear-gradient(45deg, #35394a 0%, #1f222e 100%);
  /* W3C */
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#35394a', endColorstr='#1f222e',GradientType=1 );
  /* IE6-9 fallback on horizontal gradient */
  position: absolute;
  left: 0;
  right: 90px;
  margin: auto;
  width: 320px;
  color: white;
  text-transform: uppercase;
  letter-spacing: 1px;
  text-align: center;
  padding: 20px 70px;
  top: 200px;
  bottom: 0;
  height: 110px;
  opacity: 0;
}
body .authent p {
  text-align: center;
  color: white;
}
body .success {
  display: none;
  color: #d5d8e2;
}
body .success p {
  font-size: 14px;
}
body p {
  color: #5B5E6F;
  font-size: 10px;
  text-align: left;
}
body .testtwo {
  left: -320px !important;
}
body .test {
  box-shadow: 0px 20px 30px 3px rgba(0, 0, 0, 0.55);
  pointer-events: none;
  top: -100px !important;
  -webkit-transform: rotateX(70deg) scale(0.8) !important;
          transform: rotateX(70deg) scale(0.8) !important;
  opacity: .6 !important;
  -webkit-filter: blur(1px);
          filter: blur(1px);
}
body .login {
  opacity: 1;
  top: 20px;
  -webkit-transition-timing-function: cubic-bezier(0.68, -0.25, 0.265, 0.85);
  -webkit-transition-property: opacity,box-shadow,top,left,-webkit-transform;
  transition-property: opacity,box-shadow,top,left,-webkit-transform;
  transition-property: transform,opacity,box-shadow,top,left;
  transition-property: transform,opacity,box-shadow,top,left,-webkit-transform;
  -webkit-transition-duration: .5s;
          transition-duration: .5s;
  -webkit-transform-origin: 161px 100%;
          transform-origin: 161px 100%;
  -webkit-transform: rotateX(0deg);
          transform: rotateX(0deg);
  position: relative;
  width: 320px;
  border-top: 2px solid #D8312A;
  height: 300px;
  position: absolute;
  left: 0;
  right: 0;
  margin: auto;
  top: 0;
  bottom: 0;
  padding: 10px 40px 10px 40px;
  background: #35394a;
  /* Old browsers */
  /* FF3.6+ */
  /* Chrome,Safari4+ */
  /* Chrome10+,Safari5.1+ */
  /* Opera 11.10+ */
  /* IE10+ */
  background: linear-gradient(45deg, #35394a 0%, #1f222e 100%);
  /* W3C */
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#35394a', endColorstr='#1f222e',GradientType=1 );
  /* IE6-9 fallback on horizontal gradient */
}
body .login .validation {
  position: absolute;
  z-index: 1;
  right: 10px;
  top: 6px;
  opacity: 0;
}

body .login_title {
  color: #fff;
  text-align: center;
  font-size: 16px;
  margin-bottom: 10px
}
body .login_fields {
   width: 100%
}
body .login_fields .icon {
  position: absolute;
  z-index: 1;
  left: 36px;
  top: 8px;
  opacity: .5;
}
body .login_fields input[type='password'] {
  color: #DC6180 !important;
}
body .login_fields input[type='text'], body .login_fields input[type='password'] {
  color: #afb1be;
  width: 190px;
  margin-top: -2px;
  background: #32364a;
  left: 0;
  padding: 10px 65px;
  border-top: 2px solid #393d52;
  border-bottom: 2px solid #393d52;
  border-right: none;
  border-left: none;
  outline: none;
  font-family: 'Gudea', sans-serif;
  box-shadow: none;
  width: 100%
}
body .login_fields__user, body .login_fields__password {
  position: relative;
}
body .login_fields__submit {
  position: relative;
  top: 20px;
  left: 0;
  width: 80%;
  right: 0;
  margin: auto;
}
body .login_fields__submit .forgot {
  float: right;
  font-size: 10px;
  margin-top: 11px;
  text-decoration: underline;
}
body .login_fields__submit .forgot a {
  color: #606479;
}
body .login_fields__submit input {
  border-radius: 50px;
  background: transparent;
  padding: 10px 50px;
  border: 2px solid #DC6180;
  color: #DC6180;
  text-transform: uppercase;
  font-size: 11px;
  -webkit-transition-property: background,color;
  transition-property: background,color;
  -webkit-transition-duration: .2s;
          transition-duration: .2s;
          width: 100%
}
body .login_fields__submit input:focus {
  box-shadow: none;
  outline: none;
}
body .login_fields__submit input:hover {
  color: white;
  background: #DC6180;
  cursor: pointer;
  -webkit-transition-property: background,color;
  transition-property: background,color;
  -webkit-transition-duration: .2s;
          transition-duration: .2s;
}

/* Color Schemes */
.love {
  position: absolute;
  right: 20px;
  bottom: 0px;
  font-size: 11px;
  font-weight: normal;
}
.love p {
  color: white;
  font-weight: normal;
  font-family: 'Open Sans', sans-serif;
}
.love a {
  color: white;
  font-weight: 700;
  text-decoration: none;
}
.love img {
  position: relative;
  top: 3px;
  margin: 0px 4px;
  width: 10px;
}

.brand {
  position: absolute;
  left: 20px;
  bottom: 14px;
}
.brand img {
  width: 30px;
}
.login-details{
	text-align: center;
	margin-top: 20px;
	color: #fff
}
.login-details h6, .login-details p{
	color: #fff;
	margin-bottom: 5px
}
</style>
</head>

<body class="layout-4">

<div id="app">
	
<div class='login'>
  <div class='login_title'>
  	<img src="<?php echo $set['logo']; ?>"  class=" mb-3"><br>
    <span>Login to your Dashboard</span>
  </div>
  <div class='login_fields'>
  	 <form method="POST" action="#">
    <div class='login_fields__user'>
      <div class='icon'>
        <img src='assets/img/user_icon_copy.png'>
      </div>
      <input placeholder='Username' type='text' name="username" tabindex="1" required autofocus>
        <div class='validation'>
          <img src='assets/img/tick.png'>
        </div>
      </input>
    </div>
    <div class='login_fields__password'>
      <div class='icon'>
        <img src='assets/img/lock_icon_copy.png'>
      </div>
      <input placeholder='Password' type='password' name="password" tabindex="2" required>
      <div class='validation'>
        <img src='assets/img/tick.png'>
      </div>
    </div>
    <div class='login_fields__submit'>
      <input type='submit' value='Log In' name="sub_login">
      
    </div>
</form>
  </div>
  
</div>

	<?php 
	if(isset($_POST['sub_login']))
	{
	    
		$username = $_POST['username'];
		$password = $_POST['password'];
	
	 $h = new Common();
	 $count = $h->Login($username,$password,'admin');
 if($count != 0)
 {
	 $_SESSION['username'] = $username;
	 ?>
	  <script src="assets/modules/izitoast/js/iziToast.min.js"></script>
	 <script>
 iziToast.success({
    title: 'Login Successfully!!',
    message: 'Welcome Admin!!',
    position: 'topRight'
  });
	 
	 setTimeout(function(){ 
	 window.location.href="dashboard.php"},3000);
	 </script>
	 <?php 
 }
 else 
 {
	 ?>
	 <script src="assets/modules/izitoast/js/iziToast.min.js"></script>
	 <script>
 iziToast.error({
    title: 'Wrong Data Enter!',
    message: 'Please Use Valid Data!!',
    position: 'topRight'
  });
	 </script>
	 <?php 
 }

		
	}
	?>
</div>

<!-- General JS Scripts -->
<?php require 'include/footer.php';?>

<script type="text/javascript">

$('input[type="text"],input[type="password"]').focus(function(){
  $(this).prev().animate({'opacity':'1'},200)
});
$('input[type="text"],input[type="password"]').blur(function(){
  $(this).prev().animate({'opacity':'.5'},200)
});

$('input[type="text"],input[type="password"]').keyup(function(){
  if(!$(this).val() == ''){
    $(this).next().animate({'opacity':'1','right' : '30'},200)
  } else {
    $(this).next().animate({'opacity':'0','right' : '20'},200)
  }
});

var open = 0;
$('.tab').click(function(){
  $(this).fadeOut(200,function(){
    $(this).parent().animate({'left':'0'})
  });
});


</script>
</body>


</html>