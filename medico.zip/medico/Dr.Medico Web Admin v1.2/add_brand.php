<?php 
require 'include/navbar.php';
require 'include/sidebar.php';
?>
        <!-- Start main left sidebar menu -->
        <?php 
		if(isset($_POST['icat']))
		{
			$dname = mysqli_real_escape_string($mysqli,$_POST['cname']);
			
			$okey = $_POST['status'];
			$popular = $_POST['popular'];
			$target_dir = "assets/category/catimg/";
			$temp = explode(".", $_FILES["cat_img"]["name"]);
$newfilename = round(microtime(true)) . '.' . end($temp);
$target_file = $target_dir . basename($newfilename);
			
			
    if(end($temp) != "jpg" && end($temp) != "png" && end($temp) != "jpeg") {
	?>
	<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
	 <script>
 iziToast.error({
    title: 'Upload Problem!!',
    message: 'Sorry, only JPG, JPEG, PNG  files are allowed !!',
    position: 'topRight'
  });
	 </script>
	<?php 
	?>
<script>
setTimeout(function(){ window.location.href="add_brand.php";}, 3000);
</script>
<?php
			}
			else 
			{
		// move_uploaded_file($_FILES["cat_img"]["tmp_name"], $target_file);
				


  $table="tbl_brand";
  $field_values=array("bname","img","status","popular");
  $data_values=array("$dname","$target_file","$okey","$popular");
  
$h = new Common();
	  $check = $h->InsertData($field_values,$data_values,$table);
if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Brand Section!!',
    message: 'Brand Insert Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
else 
{

?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
	 <script>
 iziToast.error({
    title: 'Operation DISABLED!!',
    message: 'For Demo purpose all  Insert/Update/Delete are DISABLED !!',
    position: 'topRight'
  });
	 </script>
<?php 	
}
?>
<script>
setTimeout(function(){ window.location.href="add_brand.php";}, 3000);
</script>
<?php 
		
		}
		}
		?>
		
		<?php 
		if(isset($_POST['ucat']))
		{
			$dname = mysqli_real_escape_string($mysqli,$_POST['cname']);
			
			$okey = $_POST['status'];
			$popular = $_POST['popular'];
			$target_dir = "assets/category/catimg/";
			$temp = explode(".", $_FILES["cat_img"]["name"]);
$newfilename = round(microtime(true)) . '.' . end($temp);
$target_file = $target_dir . basename($newfilename);
			
	if($_FILES["cat_img"]["name"] != '')
	{		
    if(end($temp) != "jpg" && end($temp) != "png" && end($temp) != "jpeg") {
	?>
	<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
	 <script>
 iziToast.error({
    title: 'Upload Problem!!',
    message: 'Sorry, only JPG, JPEG, PNG  files are allowed !!',
    position: 'topRight'
  });
	 </script>
	<?php 
	?>
<script>
setTimeout(function(){ window.location.href="add_brand.php";}, 3000);
</script>
<?php
			}
			else 
			{
		// move_uploaded_file($_FILES["cat_img"]["tmp_name"], $target_file);
				 
$table="tbl_brand";
  $field = array('bname'=>$dname,'status'=>$okey,'img'=>$target_file,'popular'=>$popular);
  $where = "where id=".$_GET['id']."";
$h = new Common();
	  $check = $h->UpdateData($field,$table,$where);
	  
if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Brand Section!!',
    message: 'Brand Update Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
else 
{

?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
	 <script>
 iziToast.error({
    title: 'Operation DISABLED!!',
    message: 'For Demo purpose all  Insert/Update/Delete are DISABLED !!',
    position: 'topRight'
  });
	 </script>
<?php 	
}
?>
<script>
setTimeout(function(){ window.location.href="list_brand.php";}, 3000);
</script>
<?php 
		
		}
	}
	else 
	{
		
		$table="tbl_brand";
  $field = array('bname'=>$dname,'status'=>$okey,'popular'=>$popular);
  $where = "where id=".$_GET['id']."";
$h = new Common();
	  $check = $h->UpdateData($field,$table,$where);
if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Brand Section!!',
    message: 'Brand Update Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
else 
{

?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
	 <script>
 iziToast.error({
    title: 'Operation DISABLED!!',
    message: 'For Demo purpose all  Insert/Update/Delete are DISABLED !!',
    position: 'topRight'
  });
	 </script>
<?php 	
}
?>
<script>
setTimeout(function(){ window.location.href="list_brand.php";}, 3000);
</script>
<?php 
	}
		}
		?>
		

        <!-- Start app main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
				<?php 
				if(isset($_GET['id']))
				{
					?>
					<h1>Edit Brand</h1>
					<?php 
				}
				else 
				{
				?>
                    <h1>Add Brand</h1>
				<?php } ?>
                </div>
				
				<div class="card">
				
				
				<?php 
				if(isset($_GET['id']))
				{
					$data = $mysqli->query("select * from tbl_brand where id=".$_GET['id']."")->fetch_assoc();
					?>
					<form method="post" enctype="multipart/form-data">
                                    
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label>Brand Name</label>
                                            <input type="text" class="form-control" placeholder="Enter Brand Name" value="<?php echo $data['bname'];?>" name="cname" required="">
                                        </div>
                                        <div class="form-group">
                                            <label>Brand Image</label>
                                            <input type="file" class="form-control" name="cat_img">
											<img src="<?php echo $data['img']?>" width="100px"/>
                                        </div>
										<div class="form-group">
                                            <label>Make A Brand Popular?</label>
                                            <select name="popular" class="form-control">
											<option value="1" <?php if($data['popular'] == 1){echo 'selected';}?>>Yes</option>
											<option value="0" <?php if($data['popular'] == 0){echo 'selected';}?> >No</option>
											</select>
                                        </div>
										
										 <div class="form-group">
                                            <label>Brand Status</label>
                                            <select name="status" class="form-control">
											<option value="1" <?php if($data['status'] == 1){echo 'selected';}?>>Publish</option>
											<option value="0" <?php if($data['status'] == 0){echo 'selected';}?> >UnPublish</option>
											</select>
                                        </div>
                                        
										
                                    </div>
                                    <div class="card-footer text-left">
                                        <button name="ucat" class="btn btn-primary">Update Brand</button>
                                    </div>
                                </form>
					<?php 
				}
				else 
				{
					?>
                                <form method="post" enctype="multipart/form-data">
                                    
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label>Brand Name</label>
                                            <input type="text" class="form-control" placeholder="Enter Brand Name"  name="cname" required="">
                                        </div>
                                        <div class="form-group">
                                            <label>Brand Image</label>
                                            <input type="file" class="form-control" name="cat_img">
											
                                        </div>
										<div class="form-group">
                                            <label>Make A Brand Popular?</label>
                                            <select name="popular" class="form-control">
											<option value="1" >Yes</option>
											<option value="0"  >No</option>
											</select>
                                        </div>
										
										 <div class="form-group">
                                            <label>Brand Status</label>
                                            <select name="status" class="form-control">
											<option value="1">Publish</option>
											<option value="0"  >UnPublish</option>
											</select>
                                        </div>
                                        
										
                                    </div>
                                    <div class="card-footer text-left">
                                        <button name="icat" class="btn btn-primary">Add Brand</button>
                                    </div>
                                </form>
				<?php } ?>
                            </div>
            </div>
					
                
            </section>
        </div>
        
       
    </div>
</div>

<?php require 'include/footer.php';?>
</body>


</html>