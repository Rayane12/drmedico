<?php
require dirname( dirname(__FILE__) ).'/include/dbconfig.php';
?>
