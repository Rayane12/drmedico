
<div class="main-sidebar sidebar-style-2">
            <aside id="sidebar-wrapper">
                <div class="sidebar-brand">
                    <a href="dashboard.php"><?php echo $set['d_title']; ?></a>
                </div>
                <div class="sidebar-brand sidebar-brand-sm">
                    <a href="dashboard.php"><?php echo $set['d_s_title']; ?></a>
                </div>
                <ul class="sidebar-menu">
                    
                    <li class="active">
                        <a href="dashboard.php" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
                     
                    </li>
                    <li class="menu-header">Medicine Section</li>
                    
					
					<li class="dropdown">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-list-ol"></i> <span>Category </span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="add_category.php">Add Category</a></li>
							<li><a class="nav-link" href="list_category.php">List Category</a></li>
                            
              
                        </ul>
                    </li>
					
					<li class="dropdown">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-image"></i> <span>Banner </span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="add_banner.php">Add Banner</a></li>
							<li><a class="nav-link" href="list_banner.php">List Banner</a></li>
                            
              
                        </ul>
                    </li>
					
					<li class="dropdown">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-gift"></i> <span>Coupon </span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="add_coupon.php">Add Coupon</a></li>
							<li><a class="nav-link" href="list_coupon.php">List Coupon</a></li>
                            
              
                        </ul>
                    </li>
					
					<li class="dropdown">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-tv"></i> <span>Brand </span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="add_brand.php">Add Brand</a></li>
							<li><a class="nav-link" href="list_brand.php">List Brand</a></li>
                            
              
                        </ul>
                    </li>
					
					
					
					<li class="dropdown">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-pills"></i> <span>Medicine </span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="add_medicine.php">Add Medicine</a></li>
							<li><a class="nav-link" href="product_import.php">Medicine Import </a></li>
							<li><a class="nav-link" href="add_medicine_attributes.php">Add Medicine Attributes</a></li>
							<li><a class="nav-link" href="list_medicine.php">List Medicine</a></li>
							<li><a class="nav-link" href="list_medicine_attributes.php">List Medicine Attributes</a></li>
                            
              
                        </ul>
                    </li>
					<li class="menu-header">Payment Gateway Section</li>
					<li><a class="nav-link" href="list_payment_list.php"><i class="fas fa-money-bill-alt"></i> <span>List Payment Gateway</span></a></li>
					
					<li class="menu-header">Delivery Boy Section</li>
					
					<li class="dropdown">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-motorcycle"></i> <span>Delivery Boy </span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="add_deliveryboy.php">Add Delivery Boy</a></li>
							<li><a class="nav-link" href="list_deliveryboy.php">List Delivery Boy</a></li>
                            
              
                        </ul>
                    </li>
					
					<li class="menu-header">Customer Section</li>
					<li><a class="nav-link" href="customer.php"><i class="fas fa-users"></i> <span>Customers</span></a></li>
                    
					
					<li class="dropdown">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-comment"></i> <span>Testimonial </span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="add_testimonial.php">Add Testimonial</a></li>
							<li><a class="nav-link" href="list_testimonial.php">List Testimonial</a></li>
                            
              
                        </ul>
                    </li>
					
					<li class="dropdown">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-flag"></i> <span>Country Code </span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link" href="add_ccode.php">Add Country Code</a></li>
							<li><a class="nav-link" href="list_ccode.php">List Country Code</a></li>
                            
              
                        </ul>
                    </li>
					 <li class="menu-header">Medicine Order Section</li>
					 <li><a class="nav-link" href="pending.php"><i class="fas fa-shopping-cart"></i> <span>Pending Order</span></a></li>
                    <li><a class="nav-link" href="complete.php"><i class="fas fa-check"></i> <span>Complete Order</span></a></li>
					<li><a class="nav-link" href="cancle_order_list.php"><i class="fas fa-times"></i> <span>Cancelled Order</span></a></li>
					
					 <li class="menu-header">Prescription Order Section</li>
					 <li><a class="nav-link" href="pending_prescription.php"><i class="fas fa-shopping-cart"></i> <span>Pending Order</span></a></li>
                    <li><a class="nav-link" href="complete_prescription.php"><i class="fas fa-check"></i> <span>Complete Order</span></a></li>
					<li><a class="nav-link" href="cancle_order_list_prescription.php"><i class="fas fa-times"></i> <span>Cancelled Order</span></a></li>
                   
                </ul>
                
            </aside>
        </div>