<?php 
require 'include/dbconfig.php';
$afile = $main['jsfile'];
echo $afile;
?>



