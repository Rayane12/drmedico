
<?php 
require 'include/navbar.php';
require 'include/sidebar.php';
?>
        <!-- Start main left sidebar menu -->
        

        <!-- Start app main Content --> 
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>Dashboard</h1>
                </div>
				<div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="card card-statistic-2">
                        <div class="card-stats">
                        <div class="card-stats-title"> Medicine Order Statistics 
                            
                        </div>
                        <div class="card-stats-items">
                            <div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_order where o_status='Pending'")->num_rows;?></div>
                                <div class="card-stats-item-label">Pending</div>
                            </div>
							<div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_order where o_status='Processing'")->num_rows;?></div>
                                <div class="card-stats-item-label">Process</div>
                            </div>
                            <div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_order where o_status='On Route'")->num_rows;?></div>
                                <div class="card-stats-item-label">On Route</div>
                            </div>
							<div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_order where o_status='Cancelled'")->num_rows;?></div>
                                <div class="card-stats-item-label">Cancel</div>
                            </div>
                            <div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_order where o_status='Completed'")->num_rows; ?></div>
                                <div class="card-stats-item-label">Completed</div>
                            </div>
                        </div>
                        </div>
                        <div class="card-icon shadow-primary bg-primary">
                        <i class="fas fa-shopping-bag heart"></i>
                        </div>
                        <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Orders</h4>
                        </div>
                        <div class="card-body">
                            <?php echo $mysqli->query("select * from tbl_order")->num_rows; ?>
                        </div>
                        </div>
                    </div>
                    </div>
					<div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="card card-statistic-2">
                        <div class="card-stats">
                        <div class="card-stats-title"> Prescription Order Statistics 
                            
                        </div>
                        <div class="card-stats-items">
                            <div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_prescription where p_status='Pending'")->num_rows;?></div>
                                <div class="card-stats-item-label">Pending</div>
                            </div>
							<div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_prescription where p_status='Processing'")->num_rows;?></div>
                                <div class="card-stats-item-label">Process</div>
                            </div>
                            <div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_prescription where p_status='On Route'")->num_rows;?></div>
                                <div class="card-stats-item-label">On Route</div>
                            </div>
							<div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_prescription where p_status='Cancelled'")->num_rows;?></div>
                                <div class="card-stats-item-label">Cancel</div>
                            </div>
                            <div class="card-stats-item">
                                <div class="card-stats-item-count"><?php echo $mysqli->query("select * from tbl_prescription where p_status='Completed'")->num_rows; ?></div>
                                <div class="card-stats-item-label">Completed</div>
                            </div>
                        </div>
                        </div>
                        <div class="card-icon shadow-primary bg-primary">
                        <i class="fas fa-pills heart"></i>
                        </div>
                        <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Prescription Orders</h4>
                        </div>
                        <div class="card-body">
                            <?php echo $mysqli->query("select * from tbl_prescription")->num_rows; ?>
                        </div>
                        </div>
                    </div>
                    </div>
					
                    <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="card card-statistic-2">
                        
                        <div class="card-icon shadow-primary bg-primary" style="color:white;font-weight:bold;">
                       <?php echo $set['currency'];?>
                        </div>
                        <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Sales</h4>
                        </div>
                        <div class="card-body heart">
                            <?php $sales  = $mysqli->query("select sum(o_total) as full_total from tbl_order where o_status='Completed'")->fetch_assoc();
               $sa = 0;
               if($sales['full_total'] == ''){echo $sa.' '.$set['currency'];}else {echo number_format((float)$sales['full_total'], 2, '.', '').' '.$set['currency']; } ?>
                        </div>
                        </div>
                    </div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="card card-statistic-2">
                       
                        <div class="card-icon shadow-primary bg-primary">
                       <i class="fas fa-money-bill-alt"></i>
                        </div>
                        <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Payment Gateway</h4>
                        </div>
                        <div class="card-body">
                            <?php echo $mysqli->query("select * from tbl_payment_list")->num_rows; ?>
                        </div>
                        </div>
                    </div>
                    </div>
					
					<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="card card-statistic-2">
                       
                        <div class="card-icon shadow-primary bg-primary">
                       <i class="fas fa-star heart"></i>
                        </div>
                        <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Customer Review</h4>
                        </div>
                        <div class="card-body">
                           0
                        </div>
                        </div>
                    </div>
                    </div>
                    
                </div>
                <div class="row">
                    
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
					<a href="list_category.php">
                        <div class="card card-statistic-1">
                            <div class="card-icon shadow-warning bg-warning">
                                <i class="fas fa-list-ol"></i>
                            </div>
                            <div class="card-wrap">
                                <div class="card-header">
                                    <h4>Total Category</h4>
                                </div>
                                <div class="card-body">
                                    <?php echo $mysqli->query("select * from category")->num_rows;?>
                                </div>
                            </div>
                        </div> 
						</a>
                    </div>
					
					<div class="col-lg-3 col-md-6 col-sm-6 col-12">
					<a href="list_banner.php">
                        <div class="card card-statistic-1">
                            <div class="card-icon shadow-info bg-info">
                                <i class="fas fa-image"></i>
                            </div>
                            <div class="card-wrap">
                                <div class="card-header">
                                    <h4>Total Banner</h4>
                                </div>
                                <div class="card-body">
                                    <?php echo $mysqli->query("select * from banner")->num_rows;?>
                                </div>
                            </div>
                        </div> 
						</a>
                    </div>
					
					<div class="col-lg-3 col-md-6 col-sm-6 col-12">
					<a href="list_coupon.php">
                        <div class="card card-statistic-1">
                            <div class="card-icon shadow-success bg-success">
                                <i class="fas fa-gift"></i>
                            </div>
                            <div class="card-wrap">
                                <div class="card-header">
                                    <h4>Total Coupon</h4>
                                </div>
                                <div class="card-body">
                                    <?php echo $mysqli->query("select * from tbl_coupon")->num_rows;?>
                                </div>
                            </div>
                        </div> 
						</a>
                    </div>
					
					<div class="col-lg-3 col-md-6 col-sm-6 col-12">
					<a href="list_brand.php">
                        <div class="card card-statistic-1">
                            <div class="card-icon shadow-primary bg-primary">
                                <i class="fas fa-tv"></i>
                            </div>
                            <div class="card-wrap">
                                <div class="card-header">
                                    <h4>Total Brand</h4>
                                </div>
                                <div class="card-body">
                                    <?php echo $mysqli->query("select * from tbl_brand")->num_rows;?>
                                </div>
                            </div>
                        </div> 
						</a>
                    </div>
					
					
					
					<div class="col-lg-3 col-md-6 col-sm-6 col-12">
					<a href="list_medicine.php">
                        <div class="card card-statistic-1">
                            <div class="card-icon shadow-warning bg-warning">
                                <i class="fas fa-pills"></i>
                            </div>
                            <div class="card-wrap">
                                <div class="card-header">
                                    <h4>Total Medicine</h4>
                                </div>
                                <div class="card-body">
                                    <?php echo $mysqli->query("select * from tbl_medicine")->num_rows;?>
                                </div>
                            </div>
                        </div> 
						</a>
                    </div>
					
					<div class="col-lg-3 col-md-6 col-sm-6 col-12">
					<a href="list_deliveryboy.php">
                        <div class="card card-statistic-1">
                            <div class="card-icon shadow-info bg-info">
                                <i class="fas fa-motorcycle"></i>
                            </div>
                            <div class="card-wrap">
                                <div class="card-header">
                                    <h4>Total Delivery Boy</h4>
                                </div>
                                <div class="card-body">
                                    <?php echo $mysqli->query("select * from rider")->num_rows;?>
                                </div>
                            </div>
                        </div> 
						</a>
                    </div>
					
					<div class="col-lg-3 col-md-6 col-sm-6 col-12">
					<a href="customer.php">
                        <div class="card card-statistic-1">
                            <div class="card-icon shadow-primary bg-primary">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="card-wrap">
                                <div class="card-header">
                                    <h4>Total Customer</h4>
                                </div>
                                <div class="card-body">
                                    <?php echo $mysqli->query("select * from tbl_user")->num_rows;?>
                                </div>
                            </div>
                        </div> 
						</a>
                    </div>
					
					<div class="col-lg-3 col-md-6 col-sm-6 col-12">
					<a href="list_testimonial.php">
                        <div class="card card-statistic-1">
                            <div class="card-icon shadow-info bg-info">
                                <i class="fas fa-comment"></i>
                            </div>
                            <div class="card-wrap">
                                <div class="card-header">
                                    <h4>Total Testimonial</h4>
                                </div>
                                <div class="card-body">
                                    <?php echo $mysqli->query("select * from tbl_happy_user")->num_rows;?>
                                </div>
                            </div>
                        </div> 
						</a>
                    </div>
					
					
					
					
                    

					
                </div>
                
                
                      
                    </div>
                </div>
            </section>
        </div>
        
       
    </div>
</div>

<?php require 'include/footer.php';?>
</body>
<style>
@keyframes heartbeat
{
  0%
  {
    transform: scale( .75 );
  }
  20%
  {
    transform: scale( 1 );
  }
  40%
  {
    transform: scale( .75 );
  }
  60%
  {
    transform: scale( 1 );
  }
  80%
  {
    transform: scale( .75 );
  }
  100%
  {
    transform: scale( .75 );
  }
}

.heart
{
  animation: heartbeat 1s infinite;
}
</style>

</html>