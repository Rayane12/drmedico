<?php 
require dirname( dirname(__FILE__) ).'/include/dbconfig.php';
$data = json_decode(file_get_contents('php://input'), true);
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
if($data['uid'] == '')
{
    $returnArr = array("ResponseCode"=>"401","Result"=>"false","ResponseMsg"=>"Something Went Wrong!");
}
else
{
	$uid = $data['uid'];
	$cartdata = $data['cartdata'];
	$cid = array();
	for($i=0;$i<count($cartdata);$i++)
{
$price = $cartdata[$i]['price'];
$discount = $cartdata[$i]['discount'];

$check = $mysqli->query("select * from tbl_medicine_attribute where id=".$cartdata[$i]['aid']."");
$count = $check->num_rows;
$fetch = $check->fetch_assoc();
if($count == 0 or $fetch['ostock'] == 1 or $fetch['price'] != $price or $fetch['discount'] != $discount)
{
	$cid[] = array("aid"=>$cartdata[$i]['aid']); 
}
else 
{
	
}
}
$cy = $mysqli->query("select * from tbl_address where uid=".$uid."");
	$p = array();
	$q = array();
	while($adata = $cy->fetch_assoc())
	{
		$p['id'] = $adata['id'];
		$p['uid'] = $adata['uid'];
		$p['hno'] = $adata['houseno'];
		$p['address'] = $adata['address'];
		$p['lat_map'] = $adata['lat_map'];
		$p['long_map'] = $adata['long_map'];
		
		$p['delivery_charge'] = $adata['distance'] * $set['pprice'];
		
		$p['landmark'] = $adata['landmark'];
		$p['type'] = $adata['type'];
		$q[] = $p;
	}
$returnArr = array("ResponseCode"=>"200","Result"=>"true","ResponseMsg"=>"Validation Get Successfully!!!","CartValidateData"=>$cid,"AddressList"=>$q);	
}
echo json_encode($returnArr);
?>