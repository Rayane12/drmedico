<?php 
require dirname( dirname(__FILE__) ).'/include/dbconfig.php';
header('Content-type: text/json');
$data = json_decode(file_get_contents('php://input'), true);
$uid = $data['uid'];
$lats = $data['lats'];
$longs = $data['longs'];
if($uid == '')
{
	$returnArr = array("ResponseCode"=>"401","Result"=>"false","ResponseMsg"=>"Something Went wrong  try again !");
}
else 
{
	
	
	$v = array();
	$cp = array(); 
	$d = array();
	$pop = array();
	$sec = array();
	$vp = array();
	$banner = $mysqli->query("select * from banner");
while($row = $banner->fetch_assoc())
{
    $vp['id'] = $row['id'];
	 $vp['img'] = $row['img'];
	  $vp['cat'] = $row['cat'];
	  $gpos= $mysqli->query("SELECT (SELECT COUNT(*) FROM `category` WHERE `id` <= ".$row['cat'].") AS `position` FROM `category` WHERE `id` = ".$row['cat']."")->fetch_assoc();
	  $vp['position'] = $gpos['position'];
	  $v[] = $vp;
}



$cat = $mysqli->query("select * from category where cat_status = 1 limit 6");
while($rows = $cat->fetch_assoc())
{
    $p['id'] = $rows['id'];
		$p['catname'] = $rows['cat_name'];
		$p['catimg'] = $rows['cat_img'];
		$p['count'] = $mysqli->query("select * from tbl_medicine where mcat=".$rows['id']." and mstatus=1")->num_rows;
		$cp[] = $p;
}

$brand = $mysqli->query("select * from tbl_brand where status=1 limit 6");
while($rowsp = $brand->fetch_assoc())
{
    $d[] = $rowsp;
}

$meidicine = $mysqli->query("select * from tbl_medicine where  mstatus=1 order by id desc limit 6");
$section = array();
while($rowkpo = $meidicine->fetch_assoc())
{
    $mattributes = $mysqli->query("select * from tbl_medicine_attribute where pid=".$rowkpo['id']." ");
      if($mattributes->num_rows != 0)
	  {
        $section['id'] = $rowkpo['id'];
    $section['product_name'] = $rowkpo['mtitle'];
    $img = explode(',',$rowkpo['m_img']);
	
	$section['product_image'] = $img;
	$bname = $mysqli->query("select * from tbl_brand where id=".$rowkpo['mbrand']."")->fetch_assoc();
	
    $section['Brand_name'] = $bname['bname'];
    $section['short_desc'] = $rowkpo['mdesc'];
	
	
	
	$pattr = array();
	$k = array();
	while($rattr = $mattributes->fetch_assoc())
	{
		$pattr['attribute_id'] = $rattr['id'];
		$pattr['product_price'] = $rattr['price'];
		$pattr['product_type'] = $rattr['title'];
		$pattr['product_discount'] = $rattr['discount'];
		$pattr['Product_Out_Stock'] = $rattr['ostock'];
		
		$k[] = $pattr;
		
	}
	$section['product_info'] = $k; 
	 
 $pop[] = $section; 
	  } 
}

$testi = $mysqli->query("select * from tbl_happy_user  order by rand() limit 6");
while($rowk = $testi->fetch_assoc())
{
    $sec[] = $rowk;
}

$main_data = $mysqli->query("select * from setting")->fetch_assoc();

$kp = array('Banner'=>$v,'Catlist'=>$cp,'Brand'=>$d,"Medicine"=>$pop,"Main_Data"=>$main_data,"testimonial"=>$sec);
	
	$returnArr = array("ResponseCode"=>"200","Result"=>"true","ResponseMsg"=>"Home Data Get Successfully!","ResultData"=>$kp);
}

echo json_encode($returnArr);