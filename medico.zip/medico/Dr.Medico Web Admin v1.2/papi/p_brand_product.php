<?php 
require dirname( dirname(__FILE__) ).'/include/dbconfig.php';
$data = json_decode(file_get_contents('php://input'), true);
$uid = $data['uid'];

$bid = $data['bid'];
if($uid == ''  or $bid == '')
{
 $returnArr = array("ResponseCode"=>"401","Result"=>"false","ResponseMsg"=>"Something Went Wrong!");    
}
else
{



	$meidicine = $mysqli->query("select * from tbl_medicine where   mbrand=".$bid." order by rand() limit 6");
$section = array();
$pop = array();
while($rowkpo = $meidicine->fetch_assoc())
{
    $mattributes = $mysqli->query("select * from tbl_medicine_attribute where pid=".$rowkpo['id']."");
      if($mattributes->num_rows != 0)
	  {
      
        $section['id'] = $rowkpo['id'];
    $section['product_name'] = $rowkpo['mtitle'];
    $img = explode(',',$rowkpo['m_img']);
	
	$section['product_image'] = $img;
	$bname = $mysqli->query("select * from tbl_brand where id=".$rowkpo['mbrand']."")->fetch_assoc();
	
    $section['Brand_name'] = $bname['bname'];
    $section['short_desc'] = $rowkpo['mdesc'];
	
	$pattr = array();
	$kps = array();
	while($rattr = $mattributes->fetch_assoc())
	{
		$pattr['attribute_id'] = $rattr['id'];
		$pattr['product_price'] = $rattr['price'];
		$pattr['product_type'] = $rattr['title'];
		$pattr['product_discount'] = $rattr['discount'];
		$pattr['Product_Out_Stock'] = $rattr['ostock'];
		
		$kps[] = $pattr;
		
	}
	
	$section['product_info'] = $kps; 
	  
 $pop[] = $section; 
	  } 
}
	
	
	if(empty($pop))
	{
		$returnArr = array("ResponseCode"=>"401","Result"=>"false","ResponseMsg"=>"Product Not Found!!","BrandProductList"=>$pop);
	}
	else 
	{
	$returnArr = array("ResponseCode"=>"200","Result"=>"true","ResponseMsg"=>"Product List Get Successfully!!","BrandProductList"=>$pop);
	}
}
echo json_encode($returnArr);
mysqli_close($con);	