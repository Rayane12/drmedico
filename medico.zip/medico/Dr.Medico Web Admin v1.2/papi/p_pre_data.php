<?php 
require dirname( dirname(__FILE__) ).'/include/dbconfig.php';
require dirname( dirname(__FILE__) ).'/include/Common.php';
header('Content-type: text/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$data = json_decode(file_get_contents('php://input'), true);

function siteURL() {
  $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || 
    $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
  $domainName = $_SERVER['HTTP_HOST'];
  return $protocol.$domainName;
}

if($data['uid'] == '' or $data['status'] == '' or $data['oid'] == '')
{
 $returnArr = array("ResponseCode"=>"401","Result"=>"false","ResponseMsg"=>"Something Went Wrong!");    
}
else
{
	$status = $data['status'];
	$oid = $data['oid'];
	$uid = $data['uid'];
	if($status == 'reject')
{
	
	
	$table="tbl_prescription";
  $field = array('order_status'=>'9','p_status'=>'Cancelled','c_accept'=>'2');
  $where = "where id=".$oid."";
$h = new Common();
	  $h->UpdateData_Api($field,$table,$where);

	$returnArr = array("ResponseCode"=>"200","Result"=>"true","ResponseMsg"=>"Order Rejected Successfully!!!!!");    
}
else if($status == 'accept')
{
	$d_charge = $data['d_charge'];
	$cou_id = $data['cou_id'];
	$cou_amt = $data['cou_amt'];
	$o_total = $data['o_total'];
	$trans_id = $data['trans_id'];
	$a_note = $data['a_note'];
	$p_method_id = $data['p_method_id'];
	$table="tbl_prescription";
  $field = array('d_charge'=>$d_charge,'cou_id'=>$cou_id,'cou_amt'=>$cou_amt,'o_total'=>$o_total,'trans_id'=>$trans_id,'a_note'=>$a_note,'c_accept'=>1,'p_method_id'=>$p_method_id);
  $where = "where id=".$oid."";
$h = new Common();
	  $h->UpdateData_Api($field,$table,$where);
	


	   
	$returnArr = array("ResponseCode"=>"200","Result"=>"true","ResponseMsg"=>"Order Accepted Successfully!!!!!");
	
}
else 
{
	
}
}
echo json_encode($returnArr);