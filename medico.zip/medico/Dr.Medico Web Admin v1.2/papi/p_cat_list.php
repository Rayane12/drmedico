<?php 
require dirname( dirname(__FILE__) ).'/include/dbconfig.php';
$data = json_decode(file_get_contents('php://input'), true);
if($data['uid'] == '')
{
    $returnArr = array("ResponseCode"=>"401","Result"=>"false","ResponseMsg"=>"Something Went Wrong!");
}
else
{
    $mobile = strip_tags(mysqli_real_escape_string($mysqli,$data['uid']));
    
    
$check = $mysqli->query("select * from category");
$op = array();
$p = array();
while($row = $check->fetch_assoc())
{
$p['id'] = $row['id'];
		$p['catname'] = $row['cat_name'];
		$p['catimg'] = $row['cat_img'];
		$p['count'] = $mysqli->query("select * from tbl_medicine where mcat=".$row['id']." and mstatus=1")->num_rows;
		$op[] = $p;
}
$returnArr = array("CategoryData"=>$op,"ResponseCode"=>"200","Result"=>"true","ResponseMsg"=>"Category Get Successfully!!");
}
echo json_encode($returnArr);