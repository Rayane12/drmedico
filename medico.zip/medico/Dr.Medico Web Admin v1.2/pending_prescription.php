<?php 
require 'include/navbar.php';
require 'include/sidebar.php';
function siteURL() {
  $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || 
    $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
  $domainName = $_SERVER['HTTP_HOST'];
  return $protocol.$domainName;
}

if(isset($_GET['did']))
{
	$id = $_GET['did'];

$table="tbl_prescription";
$where = "where id=".$id."";
$h = new Common();
	$check = $h->Deletedata($where,$table);
	

if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.error({
    title: 'Prescription Section!!',
    message: 'Prescription Order Delete Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}
?>
<script>
setTimeout(function(){ window.location.href="pending_prescription.php";}, 3000);
</script>
<?php 
}
?>

<?php 
if(isset($_GET['done_cart']))
{
	$id = $_GET['done_cart'];
$status = 1;
$check_product = $mysqli->query("select * from tbl_pre_product where oid=".$id."")->num_rows;
if($check_product != 0)
{
	$table="tbl_prescription";
$field = "setcart=".$status."";
  $where = "where id=".$id."";
$h = new Common();
	  $check = $h->UpdateData_single($field,$table,$where);	
	$checks = $mysqli->query("select * from tbl_prescription where id=".$id."")->fetch_assoc(); 
	$uid = $checks['uid'];
	$udata = $mysqli->query("select * from tbl_user where id=".$checks['uid']."")->fetch_assoc();
$name = $udata['fname'].' '.$udata['lname'];
 $timestamp = date("Y-m-d H:i:s");

$title_main = "Prescription Order Cart Ready!!";
$description = $name.', Your Prescription Order #'.$id.' Cart Ready.';

$table="tbl_notification";
  $field_values=array("uid","datetime","title","description");
  $data_values=array("$uid","$timestamp","$title_main","$description");
  
      $h = new Common();
	   $h->Insertdata($field_values,$data_values,$table);
	   
	   
$content = array(
       "en" => $name.', Your Prescription Order #'.$id.' Cart Ready.'
   );
$heading = array(
   "en" => "Prescription Order Cart Ready!!"
);

$fields = array(
'app_id' => $set['one_key'],
'included_segments' =>  array("Active Users"),
'data' => array("order_id" =>$id,"type"=>'prescription'),
'filters' => array(array('field' => 'tag', 'key' => 'userid', 'relation' => '=', 'value' => $checks['uid'])),
'contents' => $content,
'headings' => $heading
);

$fields = json_encode($fields);

 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
curl_setopt($ch, CURLOPT_HTTPHEADER, 
array('Content-Type: application/json; charset=utf-8',
'Authorization: Basic '.$set['one_hash']));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_POST, TRUE);
curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
 
$response = curl_exec($ch);
curl_close($ch);

if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Prescription Section!!',
    message: 'Cart Done Successfully!!',
    position: 'topRight'
  });
  </script>
  <script>
setTimeout(function(){ window.location.href="pending_prescription.php";}, 3000);
</script>
<?php 
}
}
else 
{
?> 
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.error({
    title: 'Prescription Section!!',
    message: 'You Need To Add At Least One Product On Cart!!',
    position: 'topRight'
  });
  </script>
   <script>
setTimeout(function(){ window.location.href="pending_prescription.php";}, 3000);
</script>
<?php 
}
}
?>


		
		<?php 
		
		if(isset($_GET['d_id']))
		{
			$checks = $mysqli->query("select * from tbl_prescription where id=".$_GET['d_id']."")->fetch_assoc(); 
			$udata = $mysqli->query("select * from tbl_user where id=".$checks['uid']."")->fetch_assoc();
$name = $udata['fname'].' '.$udata['lname'];
		$id = $_GET['d_id'];
$status = $_GET['a_status'];

$uid = $checks['uid'];
		$oid = $_GET['d_id'];
 
 if($_GET['a_status'] == 1)
 {
$table="tbl_prescription";
  $field = array('a_status'=>$status,'order_status'=>1);
  $where = "where id=".$id."";
$h = new Common();
$check = $h->UpdateData($field,$table,$where); 
 $timestamp = date("Y-m-d H:i:s");

$title_main = "Prescription Order Confirmed!!";
$description = $name.', Your Prescription Order #'.$oid.' Has Been Confirmed.';

$table="tbl_notification";
  $field_values=array("uid","datetime","title","description");
  $data_values=array("$uid","$timestamp","$title_main","$description");
  
      $h = new Common();
	   $h->Insertdata($field_values,$data_values,$table);
	   
	   
$content = array(
       "en" => $name.', Your Prescription Order #'.$_GET['id'].' Has Been Confirmed.'
   );
$heading = array(
   "en" => "Prescription Order Confirmed!!"
);

$fields = array(
'app_id' => $set['one_key'],
'included_segments' =>  array("Active Users"),
'data' => array("order_id" =>$_GET['id'],"type"=>'prescription'),
'filters' => array(array('field' => 'tag', 'key' => 'userid', 'relation' => '=', 'value' => $checks['uid'])),
'contents' => $content,
'headings' => $heading,
'big_picture' => siteURL().'/order_process_img/confirmed.png'
);

$fields = json_encode($fields);

 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
curl_setopt($ch, CURLOPT_HTTPHEADER, 
array('Content-Type: application/json; charset=utf-8',
'Authorization: Basic '.$set['one_hash']));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_POST, TRUE);
curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
 
$response = curl_exec($ch);
curl_close($ch);

if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Prescription Order Section!!',
    message: 'Prescription Order Approve Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}

 }
 if($_GET['a_status'] == 2)
 {
	$table="tbl_prescription";
  $field = array('a_status'=>$status,'p_status'=>'Cancelled','order_status'=>2);
  $where = "where id=".$id."";
$h = new Common();
	  $check = $h->UpdateData($field,$table,$where); 
	  
	  if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.error({
    title: 'Prescription Order Section!!',
    message: 'Prescription Order Reject Successfully!!',
    position: 'topRight'
  });
  </script>
  
<?php 
}


 }
 
  
?>
<script>
setTimeout(function(){ window.location.href="pending_prescription.php";}, 3000);
</script>
<?php 	  
		}
		?>
        <!-- Start app main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>Pending Prescription Order List</h1>
                </div>
				<div class="card">
				
                               <div class="card-body">
							   <?php
							   if(isset($_GET['oid']))
				{
							   ?>
							   <form class="form" method="post" enctype="multipart/form-data">
							<div class="form-body">
								

							<?php 
							$odata = $mysqli->query("select * from tbl_prescription where id=".$_GET['oid']."")->fetch_assoc();
							?>

								<div class="form-group">
									<label for="cname">Select Delivery Boy</label>
									<select name="srider" class="form-control">
									<option value="">select a Delivery Boy</option>
									<?php 
									$rid = $mysqli->query("select * from rider where a_status=1 and status=1");
									while($ro = $rid->fetch_assoc())
									{
									?>
									<option value="<?php echo $ro['id'];?>"><?php echo $ro['name'];?></option>
									<?php } ?>
									</select>
								</div>
                                
								
								
								<div class="card-footer text-left">
                                        <button name="assign_rider" class="btn btn-primary">Assign Rider</button>
                                    </div>
								</div>
								</form>
								
								<?php 
					if(isset($_POST['assign_rider']))
					{
						
						$rid = $_POST['srider'];
						
						$id = $_GET['oid'];
						$check = $mysqli->query("select * from tbl_prescription where id=".$id."")->fetch_assoc();
						if($check['order_status'] != 4)
						{
							$getdata = $mysqli->query("select * from rider where id=".$rid."")->fetch_assoc();
							$dcommission = $getdata['commission'];
						$table="tbl_prescription";
  $field = array('rid'=>$rid,'order_status'=>3);
  $where = "where id=".$id."";
$h = new Common();
	  $check = $h->UpdateData($field,$table,$where);
	  
	  
	  $timestamp = date("Y-m-d H:i:s");
						


 $table="tbl_rnoti";
  $field_values=array("rid","msg","date");
  $data_values=array("$rid",'You have an Prescription order assigned to you.',"$timestamp");
  
$hs = new Common();
	   $hs->InsertData($field_values,$data_values,$table);
	  
											$content = array(
"en" => 'You have an order assigned to you.'//mesaj burasi
);
$fields = array(
'app_id' => $set['r_key'],
'included_segments' =>  array("Active Users"),
'filters' => array(array('field' => 'tag', 'key' => 'rider_id', 'relation' => '=', 'value' => $rid)),
'contents' => $content
);
$fields = json_encode($fields);

 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
curl_setopt($ch, CURLOPT_HTTPHEADER, 
array('Content-Type: application/json; charset=utf-8',
'Authorization: Basic '.$set['r_hash']));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_POST, TRUE);
curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
 
$response = curl_exec($ch);
curl_close($ch);

if($check == 1)
{
?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.success({
    title: 'Delivery Boy Section!!',
    message: 'Delivery Boy Assigned Successfully!!',
    position: 'topRight'
  });
  setTimeout(function(){ window.location.href="pending_prescription.php";}, 3000);
  </script>
  
<?php 
}

						}
						else 
						{
							?>
<script src="assets/modules/izitoast/js/iziToast.min.js"></script>
 <script>
 iziToast.error({
    title: 'Delivery Boy Section!!',
    message: 'Assign Delivery Boy Already Accepted Order So Can not Change Delivery Boy!!',
    position: 'topRight'
  });
  setTimeout(function(){ window.location.href="pending_prescription.php";}, 3000);
  </script>
							<?php 
						}
					}
				}
					else 
					{
					?>
                                    <div class="table-responsive">
                                        <table class="table table-striped v_center" id="table-1">
                                            <thead>
                                                <tr>
                                               <th>#</th>
												 <th>Order Id</th>
                                                 <th>Order Date </th>
												 <th>Delivery Boy Name</th>
                                                 <th>Current Status</th>
												 <th>Order Flow</th>
                                                 <th>Preview Data</th>
												<th>Order Assign?</th>
												 <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
											<?php 
											 $stmt = $mysqli->query("SELECT * FROM `tbl_prescription` where p_status!='Cancelled' and p_status!='Completed' order by id desc");

while($row = $stmt->fetch_assoc())
{
	
											?>
                                                <tr>
												
												 <?php 
												if($row['p_status'] == 'Pending')
												{
													?>
												<td class="beep"></td>
                                                <?php } else if($row['p_status'] == 'Processing') {?>
												<td class="beeps">  </td>
                                                <?php } else {?>
												<td class="beepss"></td>
												<?php }?>
												<td > <?php echo $row['id']; ?> </td>
                                               
                                                
                                               <td> <?php 
											   $date=date_create($row['p_date']);
echo date_format($date,"d-m-Y");
											   ?></td>
											     <td><?php $rdata = $mysqli->query("select * from rider where id=".$row['rid']."")->fetch_assoc(); if($rdata['name'] == '') {echo '';}else {echo $rdata['name'];}?></td>
											   <td> <?php echo $row['p_status']; ?></td>
											    <td><?php 
											   if($row['order_status'] == 0)
											   {
												   ?>
												   <span class="badge badge-primary">Waiting For Decision</span>
												   <?php 
											   }
											   else if($row['order_status'] == 1)
											   {
												  ?>
												   <span class="badge badge-primary">Accepted Waiting For Assign</span>
												   <?php  
											   }
											   else if($row['order_status'] == 2)
											   {
												  ?>
												   <span class="badge badge-danger">Cancelled By You</span>
												   <?php  
											   }
											   else if($row['order_status'] == 3)
											   {
												  ?>
												   <span class="badge badge-primary">Waiting For Delivery Boy Decision</span>
												   <?php  
											   }
											   else if($row['order_status'] == 4)
											   {
												  ?>
												   <span class="badge badge-primary">Delivery Boy Accepted Order</span>
												   <?php  
											   }
											   else if($row['order_status'] == 5)
											   {
												  ?>
												   <span class="badge badge-primary">Delivery Boy Reject Order</span>
												   <?php  
											   }
											   else if($row['order_status'] == 6)
											   {
												  ?>
												   <span class="badge badge-primary">Delivery Boy PickUp Order</span>
												   <?php  
											   }
											   else if($row['order_status'] == 7)
											   {
												  ?>
												   <span class="badge badge-primary">Delivery Boy Completed Order</span>
												   <?php  
											   }
											   else if($row['order_status'] == 8)
											   {
												  ?>
												   <span class="badge badge-primary">Cancelled By Customer</span>
												   <?php  
											   }
											   else if($row['order_status'] == 9)
											   {
												  ?>
												   <span class="badge badge-primary">Delivery Boy Cancelled Order</span>
												   <?php  
											   }
											   else 
											   {
											   }
											   ?></td>
												 <td> <button class="preview_d btn btn-primary" data-id="<?php echo $row['id'];?>" data-toggle="modal" data-target="#myModal">Preview</button></td>
                                                <td>
												<a href="?oid=<?php echo $row['id']; ?>"   class="btn btn-info <?php if($row['order_status'] == 0 or  $row['setcart'] == 0 or $row['c_accept'] == 0  or $row['c_accept'] == 2 or $row['p_status'] == 'Cancelled' or $row['order_status'] == 2 or $row['order_status'] == 3 or $row['order_status'] == 4 or $row['order_status'] == 6 or $row['order_status'] == 7 or $row['order_status'] == 8){ echo 'disabled'; } ?>"><?php if($row['order_status'] == 5){?>Reassign Delivery Boy<?php } else { ?>Assign Delivery Boy<?php } ?></a>
												</td>
												
												<td>
												<?php if($row['a_status'] == 0){?>
												<a href="?d_id=<?php echo $row['id']; ?>&a_status=1" onclick="return confirm('Are you sure you want to Approve this Order?');" class="btn btn-success">Approve</a>
												<a href="?d_id=<?php echo $row['id']; ?>&a_status=2" onclick="return confirm('Are you sure you want to Reject this Order?');" class="btn btn-danger">Reject</a>
												<?php }else if($row['a_status'] == 1) {?>
												<?php 
												if($row['setcart'] == 1)
												{
													?>
													<span class="text text-success"> Accepted & Medicine Added </span>
													<?php 
												}
												else 
												{
												?>
												<span class="text text-success"><a href="set_cart.php" class="btn btn-success" data-toggle="tooltip" data-placement="bottom" title="Add Customer Medicine" ><i class="fas fa-plus"></i> <i class="fas fa-user"></i><i class="fas fa-pills"></i></a> <a href="?done_cart=<?php echo $row['id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Send To Customer" class="btn btn-info"> <i class="fa fa-paper-plane" aria-hidden="true"></i> <i class="fas fa-user"></i></a> <a href="add_medicine.php" class="btn btn-warning" data-toggle="tooltip" data-placement="bottom" title="Add New Medicine"><i class="fas fa-plus"></i> <i class="fas fa-pills"></i></a></span>
												<?php } ?>
												<?php } else { ?>
												<span class="text text-danger"> Rejected </span>
												<?php } ?>
												
												</td>
												
                                                </tr>
<?php } ?>                                           
                                            </tbody>
                                        </table>
                                    </div>
					<?php } ?>
                                </div>
                            </div>
            </div>
					
                
            </section>
        </div>
        
       
    </div>
</div>

<?php require 'include/footer.php';?>
</body>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    
    <div class="modal-content">
      <div class="modal-header">
        <h4>Prescription Order Preivew</h4>
        <button type="button" class="close" data-dismiss="modal" style="position: absolute;
    right: 0;
    top: 0;
    width: 50px;
    height: 50px;
    border-radius: 29px;
    padding: 10px;
    background: #D9534F;
    color: #fff;
    opacity: 1;">&times;</button>
      </div>
      <div class="modal-body p_data">
      
      </div>
     
    </div>

  </div>
</div>

<?php 
 echo $main['prescriptionfile'];
 ?>

</html>